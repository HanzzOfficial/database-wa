const TelegramBot = require('node-telegram-bot-api');
const { Octokit } = require('octokit');
const fs = require('fs-extra');
const config = require('./config');
const archiver = require('archiver');
const path = require('path');

// Inisialisasi bot
const bot = new TelegramBot(config.BOT_TOKEN, { polling: true });

// Inisialisasi GitHub client
const octokit = new Octokit({ auth: config.GITHUB_TOKEN });

// Konstanta untuk path database di GitHub
const DB_PATH = 'db.json';

// Variabel untuk menyimpan statistik user
const userStats = new Map();

// Fungsi untuk logging
function logCommand(user, command, args = '') {
    const timestamp = new Date().toLocaleString('id-ID');
    const username = user.username ? `@${user.username}` : user.first_name;
    console.log(`[${timestamp}] Command: ${command} | User: ${username} (${user.id}) | Args: ${args}`);
}

// Fungsi untuk update statistik user
function updateUserStats(userId, action) {
    if (!userStats.has(userId)) {
        userStats.set(userId, {
            name: '',
            addCount: 0,
            delCount: 0
        });
    }
    
    const stats = userStats.get(userId);
    if (action === 'add') stats.addCount++;
    if (action === 'del') stats.delCount++;
}

// Fungsi untuk backup script bot
async function backupScript() {
    try {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const backupDir = path.join(__dirname, 'backups');
        const zipPath = path.join(backupDir, `bot-backup-${timestamp}.zip`);
        
        // Buat direktori backups jika belum ada
        await fs.ensureDir(backupDir);
        
        // Buat file ZIP
        const output = fs.createWriteStream(zipPath);
        const archive = archiver('zip', {
            zlib: { level: 9 } // Level kompresi maksimal
        });

        output.on('close', async () => {
            console.log(`[${new Date().toLocaleString('id-ID')}] Backup script created: ${zipPath}`);
            
            // Baca file ZIP
            const zipContent = await fs.readFile(zipPath);
            const zipBase64 = zipContent.toString('base64');

            // Upload ke GitHub
            const backupPath = `backups/bot-backup-${timestamp}.zip`;
            await octokit.rest.repos.createOrUpdateFileContents({
                owner: config.GITHUB_OWNER,
                repo: config.GITHUB_REPO,
                path: backupPath,
                message: `Backup script ${timestamp}`,
                content: zipBase64,
                branch: 'main'
            });

            // Kirim link backup ke owner
            const backupUrl = `https://raw.githubusercontent.com/${config.GITHUB_OWNER}/${config.GITHUB_REPO}/main/${backupPath}`;
            for (const ownerId of config.OWNER_IDS) {
                try {
                    await bot.sendMessage(ownerId, `📦 *Backup Script Bot*\n\n` +
                        `Waktu: ${new Date().toLocaleString('id-ID')}\n` +
                        `Link: ${backupUrl}\n\n` +
                        `*Statistik User Premium:*\n` +
                        Array.from(userStats.entries())
                            .filter(([_, stats]) => stats.addCount > 0)
                            .map(([id, stats]) => 
                                `• ${stats.name}: ${stats.addCount} nomor ditambahkan`
                            ).join('\n'), {
                        parse_mode: 'Markdown'
                    });
                } catch (error) {
                    console.error(`Failed to send backup notification to ${ownerId}`);
                }
            }

            // Hapus file ZIP lokal
            await fs.remove(zipPath);
        });

        archive.on('error', (err) => {
            throw err;
        });

        archive.pipe(output);

        // Tambahkan file-file yang akan di-backup
        archive.file('index.js', { name: 'index.js' });
        archive.file('config.js', { name: 'config.js' });
        archive.file('package.json', { name: 'package.json' });
        archive.file('premium.json', { name: 'premium.json' });

        await archive.finalize();
    } catch (error) {
        console.error('Backup script failed:', error);
    }
}

// Fungsi untuk auto reload script
async function watchScriptChanges() {
    const files = ['index.js', 'config.js'];
    
    for (const file of files) {
        fs.watchFile(file, async (curr, prev) => {
            if (curr.mtime !== prev.mtime) {
                console.log(`[${new Date().toLocaleString('id-ID')}] File ${file} berubah, melakukan reload...`);
                
                // Backup script sebelum reload
                await backupScript();
                
                // Reload config jika config.js berubah
                if (file === 'config.js') {
                    delete require.cache[require.resolve('./config')];
                    Object.assign(config, require('./config'));
                }
                
                // Reload bot jika index.js berubah
                if (file === 'index.js') {
                    console.log('Bot akan di-restart dalam 5 detik...');
                    setTimeout(() => {
                        process.exit(0); // Bot akan di-restart oleh PM2 atau sistem
                    }, 5000);
                }
            }
        });
    }
}

// Mulai watch script changes
watchScriptChanges();

// Set interval untuk backup setiap 5 jam
setInterval(backupScript, 5 * 60 * 60 * 1000);

// Fungsi untuk memeriksa owner
function isOwner(userId) {
    return config.OWNER_IDS.includes(userId.toString());
}

// Fungsi untuk membaca database dari GitHub
async function readDatabase() {
    try {
        const response = await octokit.rest.repos.getContent({
            owner: config.GITHUB_OWNER,
            repo: config.GITHUB_REPO,
            path: DB_PATH,
            ref: 'main'
        });

        const content = Buffer.from(response.data.content, 'base64').toString();
        return JSON.parse(content);
    } catch (error) {
        console.error('Error reading database from GitHub:', error);
        return [];
    }
}

// Fungsi untuk menulis database ke GitHub
async function writeDatabase(numbers) {
    try {
        const content = JSON.stringify(numbers, null, 2);
        const contentBase64 = Buffer.from(content).toString('base64');

        // Get current file SHA if exists
        let sha;
        try {
            const response = await octokit.rest.repos.getContent({
                owner: config.GITHUB_OWNER,
                repo: config.GITHUB_REPO,
                path: DB_PATH,
                ref: 'main'
            });
            sha = response.data.sha;
        } catch (error) {
            // File doesn't exist yet, that's okay
        }

        await octokit.rest.repos.createOrUpdateFileContents({
            owner: config.GITHUB_OWNER,
            repo: config.GITHUB_REPO,
            path: DB_PATH,
            message: 'Update database',
            content: contentBase64,
            sha: sha,
            branch: 'main'
        });

        return true;
    } catch (error) {
        console.error('Error writing database to GitHub:', error);
        return false;
    }
}

// Fungsi untuk membaca premium users
async function readPremium() {
    try {
        const data = await fs.readJson(config.PREMIUM_FILE);
        return data;
    } catch (error) {
        return { users: [] };
    }
}

// Command /start
bot.onText(/\/start/, async (msg) => {
    const chatId = msg.chat.id;
    const isUserOwner = isOwner(msg.from.id);
    
    const keyboard = {
        inline_keyboard: [
            [
                { text: config.BUTTONS.LIST_DB, callback_data: 'listdb' },
                { text: config.BUTTONS.ADD_NUMBER, callback_data: 'adddb' }
            ],
            [
                { text: config.BUTTONS.DEL_NUMBER, callback_data: 'deldb' },
                { text: config.BUTTONS.UPDATE_DB, callback_data: 'updatesc' }
            ],
            [
                { text: config.BUTTONS.CONTACT_OWNER, callback_data: 'contact' }
            ]
        ]
    };

    // Tambahkan tombol admin jika user adalah owner
    if (isUserOwner) {
        keyboard.inline_keyboard.push([
            { text: config.BUTTONS.ADMIN_PANEL, callback_data: 'admin' }
        ]);
    }

    const commandsList = `🤖 *Daftar Command*\n\n` +
        `*Command Umum:*\n` +
        `• /start - Menampilkan menu utama\n` +
        `• /cekidtele - Menampilkan ID Telegram Anda\n\n` +
        `*Command Database:*\n` +
        `• /adddb [nomor] - Menambahkan nomor ke database\n` +
        `• /deldb [nomor] - Menghapus nomor dari database\n` +
        `• /listdb - Menampilkan semua nomor dalam database\n\n` +
        `*Command Premium:*\n` +
        `• /addprem [id] - Menambahkan user premium\n` +
        `• /delprem [id] - Menghapus user premium\n` +
        `• /stats - Menampilkan statistik user premium\n\n` +
        `💡 *Cara Penggunaan:*\n` +
        `• Gunakan tombol di bawah untuk navigasi\n` +
        `• Command database hanya untuk owner\n` +
        `• Command premium hanya untuk owner\n` +
        `• Untuk akses premium, hubungi owner`;

    try {
        await bot.sendPhoto(chatId, config.MENU_PHOTO, {
            caption: commandsList,
            parse_mode: 'Markdown',
            reply_markup: keyboard
        });
    } catch (error) {
        // Jika gagal mengirim foto, kirim pesan tanpa foto
        await bot.sendMessage(chatId, commandsList, {
            parse_mode: 'Markdown',
            reply_markup: keyboard
        });
    }
});

// Command /cekidtele
bot.onText(/\/cekidtele/, (msg) => {
    const userId = msg.from.id;
    const username = msg.from.username ? `@${msg.from.username}` : 'Tidak ada username';
    const firstName = msg.from.first_name;
    const lastName = msg.from.last_name || '';
    
    const userInfo = `👤 *Informasi User*\n\n` +
        `🆔 ID: \`${userId}\`\n` +
        `👤 Nama: ${firstName} ${lastName}\n` +
        `📱 Username: ${username}\n\n` +
        `💡 *Cara menggunakan ID:*\n` +
        `• Copy ID di atas\n` +
        `• Gunakan untuk perintah admin\n` +
        `• ID ini unik untuk setiap user`;

    bot.sendMessage(msg.chat.id, userInfo, {
        parse_mode: 'Markdown'
    });
});

// Command /adddb
bot.onText(/\/adddb (.+)/, async (msg, match) => {
    if (!isOwner(msg.from.id)) {
        return bot.sendMessage(msg.chat.id, config.MESSAGES.NO_ACCESS);
    }

    logCommand(msg.from, '/adddb', match[1]);

    const number = match[1];
    const db = await readDatabase();
    
    if (db.includes(number)) {
        return bot.sendMessage(msg.chat.id, config.MESSAGES.NUMBER_EXISTS);
    }

    db.push(number);
    const success = await writeDatabase(db);
    
    if (success) {
        updateUserStats(msg.from.id, 'add');
        userStats.get(msg.from.id).name = msg.from.first_name;
        bot.sendMessage(msg.chat.id, config.MESSAGES.ADD_SUCCESS.replace('%s', number));
    } else {
        bot.sendMessage(msg.chat.id, config.MESSAGES.GITHUB_ERROR);
    }
});

// Command /deldb
bot.onText(/\/deldb (.+)/, async (msg, match) => {
    if (!isOwner(msg.from.id)) {
        return bot.sendMessage(msg.chat.id, config.MESSAGES.NO_ACCESS);
    }

    logCommand(msg.from, '/deldb', match[1]);

    const number = match[1];
    const db = await readDatabase();
    
    if (!db.includes(number)) {
        return bot.sendMessage(msg.chat.id, config.MESSAGES.NUMBER_NOT_FOUND);
    }

    const newDb = db.filter(n => n !== number);
    const success = await writeDatabase(newDb);
    
    if (success) {
        updateUserStats(msg.from.id, 'del');
        userStats.get(msg.from.id).name = msg.from.first_name;
        bot.sendMessage(msg.chat.id, config.MESSAGES.DEL_SUCCESS.replace('%s', number));
    } else {
        bot.sendMessage(msg.chat.id, config.MESSAGES.GITHUB_ERROR);
    }
});

// Command /listdb
bot.onText(/\/listdb/, async (msg) => {
    if (!isOwner(msg.from.id)) {
        return bot.sendMessage(msg.chat.id, config.MESSAGES.NO_ACCESS);
    }

    logCommand(msg.from, '/listdb');

    const db = await readDatabase();
    const numbers = db.join('\n');
    bot.sendMessage(msg.chat.id, `📋 *Daftar nomor dalam database:*\n\n${numbers}`, {
        parse_mode: 'Markdown'
    });
});

// Command /stats
bot.onText(/\/stats/, async (msg) => {
    if (!isOwner(msg.from.id)) {
        return bot.sendMessage(msg.chat.id, config.MESSAGES.NO_ACCESS);
    }

    logCommand(msg.from, '/stats');

    const stats = Array.from(userStats.entries())
        .filter(([_, stats]) => stats.addCount > 0)
        .map(([id, stats]) => 
            `• ${stats.name}: ${stats.addCount} nomor ditambahkan`
        ).join('\n');

    bot.sendMessage(msg.chat.id, `📊 *Statistik User Premium*\n\n${stats || 'Belum ada data'}`, {
        parse_mode: 'Markdown'
    });
});

// Update callback query handler
bot.on('callback_query', async (callbackQuery) => {
    const chatId = callbackQuery.message.chat.id;
    const data = callbackQuery.data;
    const userId = callbackQuery.from.id;

    switch (data) {
        case 'listdb':
            if (!isOwner(userId)) {
                return bot.answerCallbackQuery(callbackQuery.id, {
                    text: config.MESSAGES.NO_ACCESS,
                    show_alert: true
                });
            }
            const db = await readDatabase();
            const numbers = db.join('\n');
            bot.sendMessage(chatId, `📋 *Daftar Nomor dalam Database:*\n\n${numbers}`, {
                parse_mode: 'Markdown'
            });
            break;

        case 'adddb':
            if (!isOwner(userId)) {
                return bot.answerCallbackQuery(callbackQuery.id, {
                    text: config.MESSAGES.NO_ACCESS,
                    show_alert: true
                });
            }
            bot.sendMessage(chatId, '📝 Silakan kirim nomor yang ingin ditambahkan dengan format:\n`/adddb 628xx`', {
                parse_mode: 'Markdown'
            });
            break;

        case 'deldb':
            if (!isOwner(userId)) {
                return bot.answerCallbackQuery(callbackQuery.id, {
                    text: config.MESSAGES.NO_ACCESS,
                    show_alert: true
                });
            }
            bot.sendMessage(chatId, '🗑 Silakan kirim nomor yang ingin dihapus dengan format:\n`/deldb 628xx`', {
                parse_mode: 'Markdown'
            });
            break;

        case 'updatesc':
            if (!isOwner(userId)) {
                return bot.answerCallbackQuery(callbackQuery.id, {
                    text: config.MESSAGES.NO_ACCESS,
                    show_alert: true
                });
            }
            
            // Buat backup script
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            const backupDir = path.join(__dirname, 'backups');
            const zipPath = path.join(backupDir, `bot-script-${timestamp}.zip`);
            
            await fs.ensureDir(backupDir);
            
            const output = fs.createWriteStream(zipPath);
            const archive = archiver('zip', {
                zlib: { level: 9 }
            });

            output.on('close', async () => {
                const zipContent = await fs.readFile(zipPath);
                const zipBase64 = zipContent.toString('base64');

                const backupPath = `backups/bot-script-${timestamp}.zip`;
                await octokit.rest.repos.createOrUpdateFileContents({
                    owner: config.GITHUB_OWNER,
                    repo: config.GITHUB_REPO,
                    path: backupPath,
                    message: `Update script ${timestamp}`,
                    content: zipBase64,
                    branch: 'main'
                });

                const scriptUrl = `https://raw.githubusercontent.com/${config.GITHUB_OWNER}/${config.GITHUB_REPO}/main/${backupPath}`;
                
                // Kirim link ke semua user premium
                const premium = await readPremium();
                for (const userId of premium.users) {
                    try {
                        await bot.sendMessage(userId, `📦 *Update Script Bot*\n\n` +
                            `Waktu: ${new Date().toLocaleString('id-ID')}\n` +
                            `Link: ${scriptUrl}\n\n` +
                            `*Cara Update:*\n` +
                            `1. Download script di link atas\n` +
                            `2. Extract file ZIP\n` +
                            `3. Ganti file lama dengan file baru\n` +
                            `4. Install dependencies: npm install\n` +
                            `5. Restart bot`, {
                            parse_mode: 'Markdown'
                        });
                    } catch (error) {
                        console.error(`Failed to send update to ${userId}`);
                    }
                }
                
                await fs.remove(zipPath);
                bot.sendMessage(chatId, '✅ Update script berhasil dikirim ke semua user premium');
            });

            archive.on('error', (err) => {
                throw err;
            });

            archive.pipe(output);
            archive.file('index.js', { name: 'index.js' });
            archive.file('config.js', { name: 'config.js' });
            archive.file('package.json', { name: 'package.json' });
            archive.file('premium.json', { name: 'premium.json' });

            await archive.finalize();
            break;

        case 'admin':
            if (!isOwner(userId)) {
                return bot.answerCallbackQuery(callbackQuery.id, {
                    text: config.MESSAGES.NO_ACCESS,
                    show_alert: true
                });
            }
            const adminKeyboard = {
                inline_keyboard: [
                    [
                        { text: config.BUTTONS.ADD_PREMIUM, callback_data: 'addprem' },
                        { text: config.BUTTONS.DEL_PREMIUM, callback_data: 'delprem' }
                    ],
                    [
                        { text: config.BUTTONS.PREM_STATS, callback_data: 'premstats' }
                    ],
                    [
                        { text: config.BUTTONS.BACK_MENU, callback_data: 'back' }
                    ]
                ]
            };
            bot.sendMessage(chatId, '👑 *Admin Panel*\n\n' +
                '*Command Premium:*\n' +
                '• /addprem [id] - Menambahkan user premium\n' +
                '• /delprem [id] - Menghapus user premium\n' +
                '• /stats - Menampilkan statistik user premium\n\n' +
                'Pilih opsi di bawah:', {
                parse_mode: 'Markdown',
                reply_markup: adminKeyboard
            });
            break;

        case 'addprem':
            if (!isOwner(userId)) {
                return bot.answerCallbackQuery(callbackQuery.id, {
                    text: config.MESSAGES.NO_ACCESS,
                    show_alert: true
                });
            }
            bot.sendMessage(chatId, '👤 Silakan kirim ID Telegram user yang ingin ditambahkan sebagai premium dengan format:\n`/addprem [ID_TELEGRAM]`', {
                parse_mode: 'Markdown'
            });
            break;

        case 'delprem':
            if (!isOwner(userId)) {
                return bot.answerCallbackQuery(callbackQuery.id, {
                    text: config.MESSAGES.NO_ACCESS,
                    show_alert: true
                });
            }
            bot.sendMessage(chatId, '👤 Silakan kirim ID Telegram user yang ingin dihapus dari premium dengan format:\n`/delprem [ID_TELEGRAM]`', {
                parse_mode: 'Markdown'
            });
            break;

        case 'premstats':
            if (!isOwner(userId)) {
                return bot.answerCallbackQuery(callbackQuery.id, {
                    text: config.MESSAGES.NO_ACCESS,
                    show_alert: true
                });
            }
            const premiumUsers = await readPremium();
            bot.sendMessage(chatId, `📊 *Premium User Statistics*\n\nTotal Premium Users: ${premiumUsers.users.length}`, {
                parse_mode: 'Markdown'
            });
            break;

        case 'back':
            // Trigger /start command to show main menu
            bot.emit('text', {
                message: {
                    chat: { id: chatId },
                    from: { id: userId }
                },
                text: '/start'
            });
            break;

        case 'contact':
            bot.sendMessage(chatId, config.MESSAGES.CONTACT_OWNER_MESSAGE, {
                parse_mode: 'Markdown'
            });
            break;
    }

    // Answer callback query to remove loading state
    bot.answerCallbackQuery(callbackQuery.id);
});

console.log('Bot telah dimulai...'); 
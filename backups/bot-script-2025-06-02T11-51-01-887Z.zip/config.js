module.exports = {
    // Bot Configuration
    BOT_TOKEN: '7412119865:AAGqG-bgE_4tDYCZOypLJjaQkfntAJjqmrI',
    BOT_NAME: 'GasPoll Database Manager Bot',
    BOT_USERNAME: '@GasPollDB_bot',
    
    // GitHub Configuration
    GITHUB_TOKEN: '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',
    GITHUB_REPO: 'database-wa',
    GITHUB_OWNER: 'HanzzOfficial',
    
    // Owner Configuration
    OWNER_IDS: ['6056097931'], // Array of owner Telegram IDs
    OWNER_USERNAME: '@GasPollMarketAndHost', // Username Telegram owner
    OWNER_LINK: 'https://t.me/GasPollMarketAndHost', // Link Telegram owner
    
    // Premium User Configuration
    PREMIUM_FILE: 'premium.json',
    
    // UI Configuration
    MENU_PHOTO: 'https://files.catbox.moe/66hnw3.jpg',
    WELCOME_MESSAGE: `👋 *Selamat Datang di GasPoll Database Manager Bot*\n\n` +
        `🤖 Bot ini membantu Anda mengelola database nomor dan user premium.\n\n` +
        `📱 *Fitur Utama:*\n` +
        `• Manajemen Database Nomor\n` +
        `• Sistem User Premium\n` +
        `• Sinkronisasi dengan GitHub\n\n` +
        `💡 Gunakan tombol di bawah untuk navigasi:\n\n` +
        `📞 *Untuk akses premium:*\n` +
        `• Hubungi owner: @GasPollMarketAndHost\n` +
        `• Atau klik: https://t.me/GasPollMarketAndHost`,
    
    // Button Text Configuration
    BUTTONS: {
        LIST_DB: '📋 List Database',
        ADD_NUMBER: '➕ Add Number',
        DEL_NUMBER: '➖ Delete Number',
        UPDATE_DB: '🔄 Update Database',
        ADMIN_PANEL: '👑 Admin Panel',
        ADD_PREMIUM: '➕ Add Premium',
        DEL_PREMIUM: '➖ Delete Premium',
        PREM_STATS: '📊 Premium Stats',
        BACK_MENU: '🔙 Back to Menu',
        CONTACT_OWNER: '📞 Hubungi Owner'
    },
    
    // Messages Configuration
    MESSAGES: {
        NO_ACCESS: '❌ Anda tidak memiliki akses untuk menggunakan perintah ini.',
        NUMBER_EXISTS: '❌ Nomor sudah ada dalam database.',
        NUMBER_NOT_FOUND: '❌ Nomor tidak ditemukan dalam database.',
        ADD_SUCCESS: '✅ Nomor %s berhasil ditambahkan ke database.',
        DEL_SUCCESS: '✅ Nomor %s berhasil dihapus dari database.',
        UPDATE_SUCCESS: '✅ Update berhasil dikirim ke semua user premium.',
        GITHUB_ERROR: '❌ Gagal mengupdate database ke GitHub.',
        USER_PREMIUM: '❌ User sudah premium.',
        USER_NOT_PREMIUM: '❌ User bukan premium.',
        ADD_PREMIUM_SUCCESS: '✅ User %s berhasil ditambahkan sebagai premium.',
        DEL_PREMIUM_SUCCESS: '✅ User %s berhasil dihapus dari premium.',
        CONTACT_OWNER_MESSAGE: `📞 *Hubungi Owner*\n\n` +
            `Untuk akses premium, silakan hubungi:\n` +
            `• Username: @GasPollMarketAndHost\n` +
            `• Link: https://t.me/GasPollMarketAndHost`
    }
}; 